//
//  KetoMojoSDK.h
//  KetoMojoSDK
//

#import <Foundation/Foundation.h>

/// Project version number for Keto_MojoSDK.
FOUNDATION_EXPORT double Keto_MojoSDKVersionNumber;

/// Project version string for Keto_MojoSDK.
FOUNDATION_EXPORT const unsigned char Keto_MojoSDKVersionString[];
